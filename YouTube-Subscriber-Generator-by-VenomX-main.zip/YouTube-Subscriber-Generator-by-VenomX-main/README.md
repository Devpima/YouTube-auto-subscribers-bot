# YouTube Subscriber Generator (Forcer) by VenomX

## Password to extract files: icgo

## Software scrapes known sites for gmails, then it creates a YouTube channels using them, and subscribes with these accounts to any channel you want.

## Subscribers usually lasts for 3-4 years in total, and they are getting REMOVED by YouTube! However the account itself is NOT getting banned.

## How to use? 

1. Download this repository by clicking on CODE > DOWNLOAD ZIP

2. Open .zip file that you downloaded from this repository and extract everything to Desktop. 

3. Open IcgoClient.exe

4. Type link of YouTube channel where you want to add Subscribers.

5. Enjoy and leave a star.

## Preview:

![image](https://user-images.githubusercontent.com/113134426/189521422-4dcf91b6-5b16-4339-b6c5-b69ebf46a535.png)
![image](https://user-images.githubusercontent.com/113134426/189521435-f036fa0d-54af-4851-9740-0ebedbc8c767.png)
![image](https://user-images.githubusercontent.com/113134426/189521447-1f630862-a444-4151-ac19-814e49831550.png)
![image](https://user-images.githubusercontent.com/113134426/189521457-582955ea-7b8e-4e16-9c29-dc794b0bec89.png)
https://www.youtube.com/channel/UCjXl1ziL6RcGYl0xRCyVU8w

